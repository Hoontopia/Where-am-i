package com.example.sec.whereami;

/**
 * Created by Factory on 2016-07-11.
 */
public class API_Key {
    static final String DAUM_KEY = "4b84abed6f29d6e833dc233ec40243ed";
    static final String GOOGLE_KEY = "AIzaSyDXbKJ9KHJQT-NHJGAVueQPAFuPaa_g73s";
}
