package com.example.sec.whereami;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by songjonghun on 2016. 7. 16..
 */
public class LocalSeeker {

    public LocalSeeker() {
    }
    /* Google Place API를 이용할경우 */
    public String searchPlace(String lat, String lng, String radius, String types) {
        return "https://maps.googleapis.com/maps/api/place/nearbysearch/json?" +
                "location=" + lat + "," + lng + "&" +
                "language=ko" + "&" +
                "types=" + types + "&" +
                "radius=" + radius + "&" +
                "key=" + API_Key.GOOGLE_KEY;
    }

    /* Google Geo API를 이용할경우 */
    public String getNearPlace(String lat, String lng) {
        return "https://maps.googleapis.com/maps/api/geocode/json?" +
                "latlng=" + lat + "," + lng + "&" +
                "language=ko" + "&" +
                "location_type=ROOFTOP" + "&" +
                "result_type=premise" + "&" +
                "key=" + API_Key.GOOGLE_KEY;
    }

    /* Url로부터 JSON DATA받아오기 */
    public String downloadFromUrl(String strUrl){
        StringBuilder sb = new StringBuilder();
        try{
            BufferedInputStream bis = null;
            URL url = new URL(strUrl);
            HttpURLConnection con = (HttpURLConnection)url.openConnection();
            int responseCode;

            con.setConnectTimeout(3000);
            con.setReadTimeout(3000);

            responseCode = con.getResponseCode();

            if(responseCode == 200){
                bis = new BufferedInputStream(con.getInputStream());
                BufferedReader reader = new BufferedReader(new InputStreamReader(bis,"UTF-8"));
                String line =null;
                while((line=reader.readLine())!=null)
                    sb.append(line);
                bis.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

}
